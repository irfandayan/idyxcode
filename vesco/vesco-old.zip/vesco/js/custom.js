/*==================================================
                   SERVICES
==================================================*/
/*
- Opne jQuery doc
- Open WOW doc

*/

$(function() {
    // animate on scroll
    new WOW().init();
    
});

/*==================================================
                   WORK
==================================================*/
/*Check doc like for error handling*/

/* Open Doc 
http://dimsemenov.com/plugins/magnific-popup/documentation.html
*/
$(function() {
	$('#work').magnificPopup({
		delegate: 'a',
		type: 'image',
		/*tLoading: 'Loading image #%curr%...',
		mainClass: 'mfp-img-mobile',*/
		gallery: {
			enabled: true,
			navigateByImgClick: true,
			preload: [0,1] // Will preload 0 - before current, and 1 after the current image
		},
		/*image: {
			tError: '<a href="%url%">The image #%curr%</a> could not be loaded.',
			titleSrc: function(item) {
				return item.el.attr('title') + '<small>by Irfan Dayan</small>';
			}
		}*/
	});
});

/*==================================================
                   TEAM
==================================================*/
$(function() {
  $("#owl-team").owlCarousel({
      items: 3,
      autoPlay: true,
      stopOnHover : true
  });
 
});


/*==================================================
                   TESTIMONIALS
==================================================*/
$(function() {
  $("#owl-testimonials").owlCarousel({
      items: 1,
      autoPlay: true,
      stopOnHover : true,
      singleItem: true
  });
 
});

/*==================================================
                   STATS
==================================================*/
$(function() {
    $('.counter-num').counterUp({
        delay: 10,
        time: 2000
    });
});

/*==================================================
                   CLIENTS
==================================================*/
$(function() {
  $("#owl-clients").owlCarousel({
      items: 6,
      autoPlay: true,
      stopOnHover : true,
  });
 
});

/*==================================================
                   NAVIGATION
==================================================*/
//jQuery to collapse the navbar on scroll
$(window).scroll(function() {
    //if ($(".navbar").offset().top > 50) {
    if ($(this).scrollTop() > 50) {
        $(".navbar-fixed-top").addClass("top-nav-collapse");
        $('#back-to-top').fadeIn();
    } else {
        $(".navbar-fixed-top").removeClass("top-nav-collapse");
        $('#back-to-top').fadeOut();
    }
});

//jQuery for page scrolling feature - requires jQuery Easing plugin
// Check project in downlaod folder of vesco
$(function() {
    // you can add click event instead of bind
    //$('a.page-scroll').bind('click', function(event) {
    $('a.page-scroll').click(function(event) {
        
        var $anchor = $(this);
        
         $('html, body').stop().animate({
            scrollTop: ($($anchor.attr('href')).offset().top - 64)
        }, 1250, 'easeInOutExpo');
        
        event.preventDefault();
    });
});

// close nav drop down on click
/* http://stackoverflow.com/questions/14203279/bootstrap-close-responsive-menu-on-click
http://stackoverflow.com/questions/11397028/document-click-function-for-touch-device

Note: Responsive Section
*/
$('.navbar-collapse ul li a').bind('click touch', function(){ 
        $('.navbar-toggle').click();
});









